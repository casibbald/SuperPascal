#ifndef _gfxtable_h_
#define _gfxtable_h_

#define FIXEDSHIFT  10
#define FIXEDAND    2047

#define ABS(a)   ((a < 0) ? -a : a)
#define SGN(a)   ((a < 0) ? -1 : 1)

extern  long cosTab[256];
extern  long sinTab[256];

extern  int yTab[200];

extern  long scaleTab[128];

void    gfxInitTables(void);

#endif
