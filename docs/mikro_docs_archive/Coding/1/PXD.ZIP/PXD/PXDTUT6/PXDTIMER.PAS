Program PXD_timer;
uses crt,dos;

var
 OLDTimerHandler : Procedure;
 Counter_value   : longint;
 Total_ticks     : longint;
 loop            : byte;
 loop2           : byte;


PROCEDURE MyTimer;
INTERRUPT;
begin
 if (loop = 100) then {only execute at 1/100 of the clock frequency}
  begin
   writeln('************** Peroxide Rulz ****************');
   loop := 0;
  end
   else inc(loop);

Total_ticks := total_ticks + Counter_value;
if (Total_ticks >= 65536) then
  begin
    asm
     pushf
    end;
    OLDTimerHandler;
   Total_ticks := Total_ticks - 65536;
  end
   else
  port[$20] := $20;
end;


PROCEDURE SetTimer(freq : word);
BEGIN
  Total_ticks := 0;
  Counter_value := 1193181 DIV freq;

  Port[$43] := 52;
  Port[$40] := Counter_value MOD 256;
  Port[$40] := Counter_value DIV 256;
END;


PROCEDURE RestoreTimer;
BEGIN
 Port[$43] := 52;
 Port[$40] := 0;
 Port[$40] := 0;
END;


BEGIN
loop := 0;
loop2 := 0;
TextColor(white);
Clrscr;
Writeln('      ****************************************************************');
Writeln('      *                                                              *');
Writeln('      *                      Using the PIT clock chip                *');
Writeln('      *                        by : Telemachos                       *');
Writeln('      *                                                              *');
Writeln('      ****************************************************************');
Writeln;
Writeln('      Hiya! ');
Writeln;
Writeln('      Welcome to the Peroxide Programming Tips #6');
Writeln('      This sample program will display the text "Peroxide Rulz" once');
Writeln('      every second using the PIT clock chip and a new timer interrupt.');
Writeln('      At the same time the main program cycles through the colors - ');
Writeln('      making the program fake a multitasking process.');
Writeln('      Experiment with the speed of the interrupt and change it to do');
Writeln('      other things both in textmode and graphic mode.                 ');
Writeln;
Writeln('      Have fun....');
Writeln;
Writeln('      Hit any key to get started....');
Writeln;
readkey;
clrscr;

SetTimer(100);
GetIntVec($8,@OLDTimerHandler);
SetIntVec($8,Addr(MyTimer));

repeat
 TextColor(loop2);
 if (loop2 < 16) then inc(loop2) else loop2 := 0;
until keypressed;

Textcolor(white);
RestoreTimer;
SetIntVec($8, @OLDTimerHandler);
END.


