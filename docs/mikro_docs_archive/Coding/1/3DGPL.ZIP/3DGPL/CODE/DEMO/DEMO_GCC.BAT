copy ..\hardware\386-gcc\*.* ..\hardware
gcc -c ../clipper/clipp-2d.c   
gcc -c ../clipper/clipp-3d.c   
gcc -c ../engine/eng-base.c   
gcc -c ../graphics/grp-base.c   
gcc -c ../graphics/grp-poly.c   
gcc -c ../graphics/grp-text.c   
gcc -c ../hardware/hardware.c
gcc -c ../trans/trans-fx.c   
gcc demo.c *.o -lm