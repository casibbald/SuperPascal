#include "alloc.h"
#include "io.h"
#include "fcntl.h"
#include "conio.h"
#include "sys/stat.h"




/*The following are the prototypes for the routine sin FADE.ASM */
void setPal(void far *pal);
void fill_pal(void far *pal,char red,char green,char blue);
void copy_pal(void far *pal,void far *pal_dest);
void sub_palette(void far *pal,void far *pal_dest);
void fade_between_once(void far *pal,void far *pal_dest);


char pal[768];
char pal2[768];



const char *image="image.raw";
const char *palf1="pal1.pal";
const char *palf2="pal2.pal";

int readstuff(const char *filename,void far *buf,unsigned length)
{
   int handle, bytes;


   if ((handle =
      sopen(filename, O_RDONLY | O_BINARY, S_IWRITE | S_IREAD)) == -1)
   {
      printf("Error Opening File\n");
      exit(1);
   }

   if ((bytes = read(handle, buf, length)) == -1) {
      printf("Read Failed.\n");
      exit(1);
   }
   return 0;
}


void fade_between_screen(void far *pal,void far *paldest)
/* This routine actually morph one palette to another */
{  int n;
   char far *buff,*buff2;
   buff=farmalloc(768*2);
   buff2=farmalloc(768);
   copyPal(paldest,buff2);
   copyPal(pal,buff);
   sub_palette(buff,buff2);
   for(n=0;n<63;++n)
    fade_between_once(buff,buff2);
   farfree(buff2);
   farfree(buff);
}



void main()
{  int n;
   asm{           /* set mode 13h video mode*/
     mov  ax,13h
     int  10h
   }

  /* read 320*200 raw image to video buffer*/

   fill_pal(&pal,0,0,0);  /* fill pal[768] with 0*/
   setPal(&pal);
   readstuff(image,(void far *)0xa0000000,64000);

  /*read palette file */
   readstuff(palf1,&pal,768);
   readstuff(palf2,&pal2,768);

   setPal(&pal);

   getch();

   fade_between_screen(&pal,&pal2);

   getch();

   fade_between_screen(&pal2,&pal);

   getch();

   asm{         /* return to text mode */
     mov ax,3h
     int 10h
   }
   printf("crosfade.exe written by Esak 1994");
}
