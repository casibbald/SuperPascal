                   This package is Shareware!

This means that you can enjoy this package freely, pass it on to
your friends, and learn from it. However, if you find that this
package (3d document and C source files) has been useful to you,
you have to register yourself to me. Registering costs US$10.00
and will allow you to use the source code in any way you like,
even commercial purpose if you want to. You will be registered
for life, which means that you can get any future versions of
Zed3D freely and use it without feeling bad in the morning. You
will be allowed to use the source code in any way you want,
even commercially. Commercial use of the documentation itself
still requires the written permission of the author.
(You still have to get the Zed3D package yourself.) Sending me 
money will encourage me in giving you more quality products like 
this. Please support the shareware concept and support the
shareware authors.

If you want to register, simply fill in the following
registration form and print it, then mail it to my snail-mail
address along with a cheque or money order for US$10.00.

--------------------8<----cut here-------------------------------

     Yes, I want to register my copy of the Zed3D document 
     and all future versions. As a bonus, I will be able to
     use the Zed3D source code in any way I please.
     Enclosed, you will find my US$10 contribution to the
     shareware concept.
     
     My name is: ___________________________________________

     Organization: _________________________________________
     
     My (snail mail) address is:
     
          __________________________________________________
     
          __________________________________________________
     
          __________________________________________________
     
     
     My e-mail address is: _________________________________
     
     
     I got Zed3D from: _____________________________________
     
     
     I would like to see this in future versions of Zed3D:
     
     _______________________________________________________
     
     _______________________________________________________
     
     _______________________________________________________
     
     _______________________________________________________
     
     
     Signature: ____________________________________________
                     ,
     Mail to:       Sebastien Loisel / Zed3D registration
                    1 J.K. Laflamme
                     ,       ,
                    Levis, Quebec, Canada
                    Postal Code G6V 3R1
                          ,
     Cheque should go to Sebastien Loisel

--------------------8<----cut here-------------------------------

