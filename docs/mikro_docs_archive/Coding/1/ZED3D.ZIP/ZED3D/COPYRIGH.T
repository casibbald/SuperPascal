Zed3D is Copyright 1994, 1995, 1996 All Rights Reserved.
Redistribution is allowed only if no fees are charged for it.
Any other form of redistribution ABSOLUTELY REQUIRES written consent of
the author. Unauthorized redistribution will be met with prosecution.
This is shareware and registration may be required under certain
conditions. For more specific information on registration, redistribution
and copyright, please see the main document, Zed3D.DOC or Zed3D.PS.
