#ifndef _gfxpal_h_
#define _gfxpal_h_

extern  char gfxPalette[768];

void    gfxSetPalette(int first, int number, char *palette);
void    gfxLoadPalette(char *palFName, char *palette);
void    gfxSavePalette(char *palFile, char *palette);
void    gfxBlackPalette(char *palette);
void    gfxFadeIn(int first, int number, char *palette);
void    gfxFadeOut(int first, int number, char *palette);
void    gfxCycleLeft(int first, int number, char far *palette);
void    gfxCycleRight(int first, int number, char *palette);

#endif
