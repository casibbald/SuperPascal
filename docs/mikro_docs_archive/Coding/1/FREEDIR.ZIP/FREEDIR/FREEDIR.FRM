TITLE    : Free Direction Rendering
AUTHOR   : kombat
GROUP    : immortals
CATEGORY : tutors/graphics
LANGUAGE : Cp
EMAIL    : eder@bigfoot.com

--DESCRIPTION-BEGIN------------------------------------------------------------

This document gives information on how to render various objects in high
quality and in real time.

--DESCRIPTION-END--------------------------------------------------------------
