{$X+}
Program Plasma;

Uses Plas,CRT;

Var
    XAnswer,YAnswer,
    ToAdd               : Real;
    X,Y                 : Integer;


Begin
    WriteLN('This program will only do one thing :(.');
    WriteLN('It will draw our basic plasma very slowly so''s you can see it');
    WriteLN('Okay so maybe it''s slow because the code''s crap');
    WriteLN('Change the numbers have a play thats what its here for.');
    ReadKey;
    SetMCGA;
    ToAdd := 0;
    While Not Keypressed Do
{Repeat this code until someone pressed escape}
        Begin
            ToAdd := ToAdd + 1;
{Here we add our small amount to our dynamic variable}
            For  X := 0 to 100 Do
                Begin
                    XAnswer := 20 * Sin(Rad((X*4) +(ToAdd)))+
                               30 * Sin(Rad((X)+(ToAdd*4)))+
                               50 * Sin(Rad((X/4) + (ToAdd/4)));
{This is our first answer for our X coordinate of the square}
                    For Y := 0 to 100 Do
                        Begin
                            YAnswer := 40 * Sin(Rad((Y*6) +(ToAdd)))+
                                       40 * Sin(Rad((Y)+(ToAdd*6)))+
                                       20 * Sin(Rad((Y) + (ToAdd/6)));
{This is our second answer for our Y coordinate of the square}
                            PutPixel(X,Y,Trunc(XAnswer+YAnswer),VGA);
                        End;
                End;
        End;
    SetText;
    WriteLN('I''m gonna say this again because it''s evident in this program a lot');
    WriteLN('This code is sloooow do not write to me saying that, I know.');
    WriteLN('Write to me if you code any plasma''s though and I''ll send you some');
    WriteLN('comments Gareth.Harper@Onyxnet.CO.Uk is the place to write.');
End.