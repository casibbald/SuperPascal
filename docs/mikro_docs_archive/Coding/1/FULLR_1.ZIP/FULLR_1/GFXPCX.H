#ifndef _gfxpcx_h_
#define _gfxpcx_h_

char    *gfxLoadPCX(char *pcxFName, char *image, char *palette);

#endif
