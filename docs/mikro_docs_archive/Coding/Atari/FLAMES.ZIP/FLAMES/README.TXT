**************************************************************************


                   F L A M E S   F O R   F A L C O N  0 3 0


                                Version 1.1

***************************************************************************


  I. FLAMES - der Kamin im Computer                             16.10.94

  Feuer auf dem Bildschirm - wie funktioniert das?
  FLAMES ist eigentlich kein Demoprogramm, sondern eher eine Simulation,
  die dem bekannten "Life"-Spiel sehr �hnlich ist.
  
  Der zugrundeliegende Algorithmus sieht kurz gefasst so aus:
  
  x0 bis X4 bezeichnen vier benachbarte Pixel des Urspungsbildes, y0 bis y4
  sind Pixel des zu berechnenden Bildes.       
  
  Ursprungsbild        folgendes Bild
  
        x0                  y0
     x1 x2 x3      --->  y1 y2 y3    wobei y0 = (x0+x1+x3+x4)/4 
        x4                  y4
  
  Der obere Pixel (y0) ergibt sich also aus der Summe der Umgebung des mit-
  tleren Pixels geteilt durch vier. Daraus erkl�rt sich auch, warum das 
  Feuer sich nach oben ausbreitet. Jeder Pixel kann einen Wert von 0 bis
  255 annehmen. Je gr�sser der Wert eines Pixels, desto heller erscheint er.
  
  Am Anfang ist das ganze Bild gel�scht; wie aber f�ngt jetzt das Feuer
  �berhaupt an zu brennen? Hier kommt der Zufallsgenerator ins Spiel, der
  das Feuer auch in Gang h�lt. Daf�r werden in den unteren drei Zeilen des
  Feldes �berall zuf�llig "Z�nder" plaziert, wobei ein "Z�nder" eine Gruppe
  aus sehr hellen Pixeln (Wert 255) ist. Dabei bestimmt der Zufallsgenerator
  nicht nur die horizontale Position der Z�nder, sondern auch die Anzahl.
   
  
  II. Technische Information

  FLAMES 030 ist die 68030-Version eines Assembler-Programms f�r den 80386.
  Diese Version l�uft nur auf dem Falcon, da es den HiColor-Modus nutzt.
  Ich habe auch eine Version f�r den 256-Farben-Modus geschrieben, diese
  ist jedoch deutlich langsamer. Am schnellsten ist FLAMES allerdings auf
  einem DOS-Rechner, hier betr�gt die Geschwindigkeit auf einem 486DX/2-66
  mindestens 30 Bilder/sec. - dies liegt allerdings nicht nur am schnelleren
  Prozessor, sondern an der f�r dieses Programm sehr vorteilhaften
  Byte-To-Pixel-Organisation der VGA-Karte.
  
  Auf meinem 32MHz-Falcon betr�gt die Geschwindigkeit ca. 9 Bilder/sec.,
  w�hrend die Schrift angezeigt wird l�uft das Programm noch etwas lang-
  samer. Eine normale 16MHz-Maschine schafft etwa 7 Bilder/sec.
  Die 256-Farben Version kommt auf ca. 4,6 Bilder/sec., daf�r l�uft sie
  wahrscheinlich auch auf einem Atari TT (leider habe ich keinen TT um das
  auszuprobieren). Eine Version, die die Bitplanes mit DSP-Unterst�tzung
  umrechnet habe ich auch noch, leider ist diese noch langsamer (wegen der
  langsamen Daten�bertragung von und zum DSP).
   
  Um das Programm zu starten, mu� der Screenblaster deaktiviert werden, da
  die Aufl�sung automatisch umgeschaltet wird (320 x 200, 65536 Farben). 
  
    Viel Spass, Martin
     
--------------------------------------------------------------------------  
  Credits: 80386 Version coded by Bernhard Schmitz
           Inspired by FIRE coded by Jare of VageliSTeam
           
--------------------------------------------------------------------------
  Contact: martin_steen @ wob.maus.de 
  
  
--------------------------------------------------------------------------