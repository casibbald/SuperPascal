{$X+}
Program Plasma;

Uses Plas,CRT;

Var
    XAnswer,YAnswer,
    ToAdd,Position,
    X,Y                 : Integer;
    SinArray            : Array [0..512] Of Integer;
    XValues             : Array [0..319] Of Integer;
{This is the array which is gonna store the x values}


Begin
    WriteLN('This program will only do one thing :(.');
    WriteLN('It will our plasma in realtime until you press a key.');
    WriteLN('Change the numbers have a play thats what its here for.');
    WriteLN('This program will be faster though because it uses arrays');
    WriteLN('This one uses fixed point and it will be even faster');
    WriteLN('This uses all the tricks (well most anyway) that I know and is fastest yet');
    ReadKey;
    SetMCGA;
{Now to create our sine array}
    For X := 0 to 512 Do
        Begin
            SinArray[X] := Trunc(Sin(Rad(X)/512*360)*1024);
        End;
    ToAdd := 0;
    While Not Keypressed Do
        Begin
            Position := 0;
            ToAdd := ToAdd + 1;
{Here we add our small amount to our dynamic variable}
            For X := 0 to 319 Do
                XValues[X] :=  20 * SinArray[((X Shl 2) + (ToAdd      )) And 511]+
                               30 * SinArray[((X      ) + (ToAdd Shl 2)) And 511]+
                               50 * SinArray[((X Shr 2) + (ToAdd Shr 2)) And 511];
{This is where we create that list of x values}
            For Y := 0 to 199 Do
                Begin
                    YAnswer := 40 * SinArray[((Y Shl 3) + (ToAdd      )) And 511]+
                               40 * SinArray[((Y      ) + (ToAdd Shl 3)) And 511]+
                               20 * SinArray[((Y      ) + (ToAdd Shr 3)) And 511];
{This is our second answer for our Y coordinate of the square}
                    For X := 0 to 319 Do
                        Begin
{This is our first answer for our X coordinate of the square}
                            XAnswer := XValues[X];
                            Mem[VGA:Position] := (XAnswer+Yanswer) Shr 10;
                            Position := Position + 1;
                        End;
                End;
        End;
    SetText;
    WriteLN('I''m gonna say this again because it''s evident in this program a lot');
    WriteLN('This code is sloooow do not write to me saying that, I know.');
    WriteLN('Write to me if you code any plasma''s though and I''ll send you some');
    WriteLN('comments Gareth.Harper@Onyxnet.CO.Uk is the place to write.');
End.