copy ..\hardware\386-wat\*.* ..\hardware
wcl386 -c ..\clipper\clipp-2d.c  
wcl386 -c ..\clipper\clipp-3d.c  
wcl386 -c ..\engine\eng-base.c  
wcl386 -c ..\graphics\grp-base.c   
wcl386 -c ..\graphics\grp-poly.c   
wcl386 -c ..\graphics\grp-text.c   
wcl386 -c ..\hardware\hardware.c
wcl386 -c ..\trans\trans-fx.c   
wcl386 /k9000 demo.c clipp-2d.obj clipp-3d.obj eng-base.obj grp-base.obj grp-poly.obj grp-text.obj hardware.obj trans-fx.obj