{$X+}
Program Sines;

Uses Plas,Crt;

Var
    Counter          : Integer;
    Angle,Temp,ToAdd : Real;
{This will be the number we put into the sine function}

Procedure SetUpAxis;
Begin
    Cls(VGA,0);
    HLine(0,319,100,9,VGA);
End;



Begin
    WriteLN('This program will do the following things');
    WriteLN('1. Display a basic sine wave');
    WriteLN('2. Display a more squashed up sine wave done by multiplying the angle by 2');
    WriteLN('3. Display a more spaced out sine wave done by dividing the angle by 2');
    WriteLN('4. Display these three sine waves all added together');
    WriteLN('5. Display how to make these sine waves move');

    ReadKey;

    SetMCGA;
    {Get us into graphics mode}

{This bit sets up the axis}
    SetUpAxis;

    For Counter := 0 to 319 Do
    {I do this only Because I use mode 13h and that can only fit 320 pixels
    on the screen so I use 0 to 180 and multiply by two}
        Begin
            Angle := Rad(Counter*2);
{Rad is a function that changes degrees into radians.  Radians are a
stupid measurement like degrees only more complex.  The Turbo Pascal
sine routine only accepts radian measurements.  We don't need to worry about
them just use the function to convert your degrees to it}
            Putpixel(Counter,100+Trunc(99*Sin(Angle)),10,VGA);
        End;
    Readkey;
    SetUpAxis;
    For Counter := 0 to 319 Do
        Begin
            Angle := Rad(Counter*4);
            Putpixel(Counter,100+Trunc(99*Sin(Angle)),11,VGA);
{I multiply by 99 to make the effect larger}
        End;
    Readkey;
    SetUpAxis;
    For Counter := 0 to 319 Do
        Begin
            Angle := Rad(Counter);
            Putpixel(Counter,100+Trunc(99*Sin(Angle)),11,VGA);
{I multiply by 99 to make the effect larger}
        End;
    Readkey;
    SetUpAxis;
    For Counter := 0 to 319 Do
        Begin
            Angle := Rad(Counter*8);
            Temp := 20 * Sin(angle);
            Angle := Rad(Counter);
            Temp := 50 * Sin(angle) + Temp;
            Angle := Rad(Counter*4);
            Temp := 30 * Sin(angle) + Temp;
            Putpixel(Counter,100+Trunc(Temp),11,VGA);
        End;
    Readkey;
    SetUpAxis;
    ToAdd := 0;
    While Not Keypressed Do
        Begin
            ToAdd := Toadd + 0.05;
            SetUpAxis;
            For Counter := 0 to 319 Do
                Begin
                    Angle := Rad(Counter*8);
                    Temp := 20 * Sin(angle+ToAdd*4);
                    Angle := Rad(Counter);
                    Temp := 50 * Sin(angle+ToAdd/2) + Temp;
                    Angle := Rad(Counter*4);
                    Temp := 30 * Sin(angle+ToAdd) + Temp;
                    Putpixel(Counter,100+Trunc(Temp),11,VGA);
                End;
            WaitRetrace;
            WaitRetrace;
        End;

    SetText;
    {Put us back in text mode}
    WriteLN('Dont send me mail telling me that these routines are crap.');
    WriteLN('I know that they are but they are to show people the basics');
    WriteLN('They are not here to show people how fast my code is');
    WriteLN('If you want fast code from me then mail me with an example of your');
    WriteLN('plasma andI will send you mine');
    WriteLN('Mail me at Gareth.Harper@Onyxnet.Co.Uk');
End.

