***********************************************************************
* 8.8 fixedpoint math-untit for  ATARI ST     (c) 2000 Reimund Dratwa *
*                                                                     *
* Hi to all Atari-Coders out there ,                                  *
*  this is my new fixedpoint handler for 68k asm. Since the ATARI STs *
*  don�t have an FPU this could be a quick and simple alternative to  *
*  floating-point calculations.                                       *
*  All needed routs are included - I�ll use this stuff for my         *
*  "ATARI ST Wolf 3D - Clone" project.                                *
*                                                                     *
*  Values (and results) have to be between -128.00 and +127.99        *
*  (in fact that's called 7.8 fixedpoint because numbers are signed)  *
*                                                                     *
* Notice : this unit is not a "stand-alone" program ! But you can     *
*          include those procs into your own code freely.             *
***********************************************************************
*                                                                     *
* Coming soon:   - 16.16 fixedpoint unit                              *
*                - Wolf 3D ! for the ATARI ST                         *
*                                                                     *
* if You got questions or problems contact: reimund.dratwa@freenet.de *
*                                                                     *
***********************************************************************

		move.w	#fp8_8pi,d0
		move.w	#$0200,d1
		bsr	mul_fp

fp8_8pi         EQU $0324       * might be useful for some of you - and
*                                 by the way ,i'm going to inculde some
*                                 trigonometric-functions, next time.



* this one converts a fixedpoint value to an integer
* input  - d0
* output - d1

fp_to_int:      move.w  D0,D1
                asr.w   #8,D1
                rts


* and this converts an integer value to fixedpoint
* input  - d0
* output - d1

int_to_fp:
                move.w  D0,D1
                asl.w   #8,D1
                rts


* those two routs add or subtract fixedpoint numbers.
* if I were you i wouldn't use these two at all ,`cause hey,
* you can add and subtract fp numbers without any
* modification.


* Add
* input  - d0,d1
* output - d1

add_fp:         add.w   D0,D1
                rts


* Subtract
* input  - d0,d1
* output - d1   (d1 = d1 - d0)

sub_fp:         sub.w   D0,D1
                rts



* that's the "complicated" part. here we multiplicate and
* divide fixedpoint numbers.


* division
* input  -  d0,d1
* output -  d1 (d1 = d1 / d0) fp


div_fp:         asr.w   #4,D0
                divs    D0,D1
                asl.w   #4,D1
                rts


* multiplication
* input  - d0,d1
* output - d1


mul_fp:         divs    #16,D1
                asr.w   #4,D0
                muls    D0,D1
                rts
                END