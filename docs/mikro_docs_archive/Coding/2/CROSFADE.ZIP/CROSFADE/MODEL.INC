MODEL large
