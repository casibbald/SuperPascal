copy ..\hardware\8086-bcc\*.* ..\hardware
bcc -c -ml ..\clipper\clipp-2d.c  
bcc -c -ml ..\clipper\clipp-3d.c  
bcc -c -ml ..\engine\eng-base.c  
bcc -c -ml ..\graphics\grp-base.c   
bcc -c -ml ..\graphics\grp-poly.c   
bcc -c -ml ..\graphics\grp-text.c   
bcc -c -ml ..\hardware\hardware.c
bcc -c -ml ..\trans\trans-fx.c   
bcc -ml demo.c clipp-2d.obj clipp-3d.obj eng-base.obj grp-base.obj grp-poly.obj grp-text.obj hardware.obj trans-fx.obj