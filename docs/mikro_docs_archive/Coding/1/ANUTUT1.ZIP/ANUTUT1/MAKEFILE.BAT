@echo off
wcc386 plasmac.c
wcc386 plasmac2.c
wlink @plasmac.lnk system pmodew
wlink @plasmac2.lnk system pmodew