program Nopause_break;
uses crt,dos;

{Now - One VERY important thing to notice here : In the text I wrote that
extended keys sends a 224 followed by the extended key-number. This is not
true for the pause key. If pause is pressed the following SIX bytes are send

       225,29,69,225,157,197

This means we have to deal with this key different from all other keys.
CTRL + Pause (BREAK) acts like a normal extended 70 key....}


var
 OLDKbdHandler : procedure;
 ch : char;
 pause : byte; {See if our handler is currently processing the pause key}
 extended : byte;{See if our handler is processing an extended key.}


{$F+}
PROCEDURE MyKbdHandler;
INTERRUPT;
VAR
 input : byte;
BEGIN
  input := Port[$60];     {port $60 is the data-port of the keyboard }

  {*********** PAUSE STUFF ****************}

  if (input = 225) and (pause = 0) then pause := 1; {a new pause press...}
  if (input = 197) and (pause = 1) then {last byte in pause scancode-stream}
   begin
     pause := 0; {ready for another pause press}
     port[$20] := $20;   { acknowledge interrupt and ignore keypress }
    end;
  if (pause = 1) then port[$20] := $20; {if pause just acknowledge int}

  {********** END OF PAUSE STUFF *************}

  if (extended = 1) then  {handle extended keys here}
    begin
      if (input = 70) then
        begin
         port[$20] := $20;   {ignore break}
        end
         else

    {************************************************************}
    {*  Here you can add any other extended keys which you want *}
    {*  to customize.                                           *}
    {************************************************************}

        begin   {if no special extended key let BIOS have a look}
           asm
            pushf
           end;
          OLDKbdHandler;
        end;
    end;


   {***********************************************************}
   {*  Here you can add normal keys to customize. If Fx. you  *}
   {*  wanted to customize the letter 'A' to call MoveLeft    *}
   {*  you would add the marked out code below this box...    *}
   {***********************************************************}

  {if (input = 30) and (pause = 0) and (extended = 0) then
   begin
    Port[$20] := $20;
    MoveLeft;
   end
    else}
  if (pause = 0) and (extended = 0) then
  {if no special key and not pause and not extended key let BIOS have a look}
    begin
      asm
       pushf
      end;
      OLDKbdHandler;
    end;
  if (input = 224) then extended := 1 else extended := 0;
   {if the current input was extended we will have to run it through the
    extended section of the handler during next interrupt}
END;
{$F-}


Procedure SetupNoPause;
begin
 pause := 0;
 extended := 0;
 GetIntVec(9, @OLDKbdHandler);        {the keyboard int is $9 }
 SetIntVec(9, Addr(MyKbdHandler));
end;

Procedure SetOLDHandlerBack;
begin
 SetIntVec(9, @OLDKbdHandler);        {the keyboard int is $9 }
end;


BEGIN
Clrscr;
Writeln('      ****************************************************************');
Writeln('      *                                                              *');
Writeln('      *                 Programming a Keyboard handler               *');
Writeln('      *                        by : Telemachos                       *');
Writeln('      *                                                              *');
Writeln('      ****************************************************************');
Writeln;
Writeln('      Hiya! ');
Writeln;
Writeln('      Welcome to the Peroxide Programming Tips #6');
Writeln('      This sample program will keep clearing the screen in some ');
Writeln('      random color in the graphic mode $13.');
Writeln('      A new keyboardhandler is installed which ignores the keys');
Writeln('      ''pause'' and ''break'' To end the program press any other key.');
Writeln('      Experiment with the handler and make it ignore other keys - or');
Writeln('      link procedures to the different keys by calling the procedures ');
Writeln('      from the handler. Remember to acknowledge for any interrupts ');
Writeln('      which does NOT reach the old keyboardhandler.');
Writeln;
Writeln('      Have fun....');
Writeln;
Writeln('      Hit any key to get started....');
Writeln;
readkey;
clrscr;

 SetUpNoPause;
 asm
  mov ax,13h
  int 10h
 end;


 repeat
  fillchar(mem[$a000:0],64000,random(200));
 until keypressed;

 asm
  mov ax,03h
  int 10h
 end;
 SetOLDHandlerBack;
END.