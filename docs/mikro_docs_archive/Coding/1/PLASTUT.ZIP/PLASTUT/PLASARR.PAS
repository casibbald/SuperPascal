{$X+}
Program Plasma;

Uses Plas,CRT;

Var
    XAnswer,YAnswer     : Real;
    ToAdd,
    X,Y                 : Integer;
    SinArray            : Array [0..360] Of Real;

Begin
    WriteLN('This program will only do one thing :(.');
    WriteLN('It will our plasma in realtime uintil you press a key.');
    WriteLN('Change the numbers have a play thats what its here for.');
    WriteLN('This program will be faster though because it uses arrays');
    ReadKey;
    SetMCGA;
{Now to create our sine array}
    For X := 0 to 360 Do
        Begin
            SinArray[X] := Sin(Rad(X));
        End;
    ToAdd := 0;
    While Not Keypressed Do
        Begin
            ToAdd := ToAdd + 1;
{Here we add our small amount to our dynamic variable}
            For  X := 0 to 100 Do
                Begin
                    XAnswer := 20 * SinArray[((X * 4  ) + (ToAdd      )) Mod 360]+
                               30 * SinArray[((X      ) + (ToAdd * 4  )) Mod 360]+
                               50 * SinArray[((X Div 4) + (ToAdd Div 4)) Mod 360];
{This is our first answer for our X coordinate of the square}
                    For Y := 0 to 100 Do
                        Begin
                            YAnswer := 40 * SinArray[((Y * 6  ) + (ToAdd      )) Mod 360]+
                                       40 * SinArray[((Y      ) + (ToAdd * 6  )) Mod 360]+
                                       20 * SinArray[((Y      ) + (ToAdd Div 6)) Mod 360];
{This is our second answer for our Y coordinate of the square}
                            PutPixel(X,Y,Trunc(XAnswer+YAnswer),VGA);
                        End;
                End;
        End;
    SetText;
    WriteLN('I''m gonna say this again because it''s evident in this program a lot');
    WriteLN('This code is sloooow do not write to me saying that, I know.');
    WriteLN('Write to me if you code any plasma''s though and I''ll send you some');
    WriteLN('comments Gareth.Harper@Onyxnet.CO.Uk is the place to write.');
End.