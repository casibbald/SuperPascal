Program PXDTECH3;
uses
 crt, TMHICOL;

var
 Xres, Yres : word;
 bpp : byte;
 code : integer;

BEGIN
clrscr;
Writeln('      ****************************************************************');
Writeln('      *                                                              *');
Writeln('      *                PXDTECH #3 : Advanced .PCX handling!          *');
Writeln('      *                    by : Telemachos^Peroxide                  *');
Writeln('      *                                                              *');
Writeln('      ****************************************************************');
Writeln;
Writeln('      Hi All! ');
Writeln('      Welcome to the third release in my new PXDTECH series!');
Writeln;
Writeln('      This one is on advanced .PCX handling/decoding in 8, 24 and 32 bit');
Writeln('      graphic modes. ');
Writeln;
Writeln('      This sample program is probably the shortest piece of code I''ll');
Writeln('      ever release to the public :) Six lines is all it takes to show');
Writeln('      a nice .PCX image made by some artist from ACID - thanx for letting');
Writeln('      me use the nice pic...');
Writeln;
Writeln('      Anyway - understand the loader included in TMHICOL and play around');
Writeln('      with different pictures in different resolutions.');
Writeln;
Writeln('      Have fun with .PCX''s in Pascal!');
Writeln('      Hit any key to start.....');
readkey;
ClrScr;

{remember how easy it is to change modes - other modes for you to try are :}
{  - SetUpVESAMode(320,200,8) - NEW FROM PXDTECH#2 : uses mode 13h if not  }
{                                                  available as a VESA mode}
{  - SetUpVESAMode(640,480,8)                                              }
{  - SetUpVESAMode(800,600,32)                                             }



if (ParamStr(1) = '') or (ParamStr(2) = '') or (ParamStr(3) ='')
 or(ParamStr(4) = '')
  then
 begin
  Writeln('Call this program with : PXDTECH3 <filename.pcx> <Xres> <Yres> <bpp>');
  Writeln('Where bpp is the bitdepth of the SCREENMODE (not picture)');
  Writeln('Remember that 24bit .PCX''s must have either 24 or 32 bpp');
  Writeln('while 8bit pictures requires a 8bit mode!');
  HALT;
 end;

val(ParamStr(2), Xres,code);
val(ParamStr(3), Yres,code);
val(ParamStr(4), bpp,code);


if not(SetUpVESAMode(Xres,Yres,bpp)) then
   Error('Error setting mode !');


VESALoadPcx(ParamStr(1),0,0,true);
readkey;
ShutVESADown;
Writeln('CU next time... ');
Writeln('Telemachos^Peroxide');
END.