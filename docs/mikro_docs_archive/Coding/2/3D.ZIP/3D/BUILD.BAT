@echo off
cls
echo Building GNL3D_R1.CPP
echo Please wait a moment.

gcc gnl3d_r1.c -ognl3d_r1.exe -m486 -s

echo Finished compiling GNL3D_R1.CPP.  You may now run the program
echo by typing GNL3D_R1 at the prompt
