Unit Plas;

Interface

Uses Crt;

Const
    VGA = $A000;

Var
    Scr_Ofs             : Array [0..199] Of Word;

Procedure SetMCGA;
Procedure SetText;
Function  Rad(Angle     : Real):Real;
Procedure CLS(Where     : Word;Colour : Byte);
Procedure HLine(X1,X2,Y : Word;Colour : Byte;Where : Word);
Procedure Putpixel(X,Y  : Word;Colour : Byte;Where : Word);
Procedure WaitRetrace;

Implementation

Procedure SetMCGA;Assembler;
Asm
    Mov AX,13h
    Int 10h
End;

Procedure SetText;Assembler;
Asm
    Mov AX,03h
    Int 10h
End;


Function Rad(Angle     : Real): Real;
Begin
    Rad := Angle*PI/180;
End;

Procedure CLS(Where     : Word;Colour   : Byte);Assembler;
Asm
    Mov AX,Where
    Mov ES,AX
    Xor DI,DI
    Mov AL,Colour
    Mov AH,AL
    Mov BX,AX
    Db 66h
    Shl AX,16
    Mov AX,BX
    Mov CX,16000
    Db 66h
    Rep Stosw
End;

Procedure HLine(X1,X2,Y : Word;Colour   : Byte;Where    :Word);Assembler;
asm
  Mov   AX,Where
  Mov   ES,AX
  Mov   BX,[Y]
  Shl   BX,1
  Mov   DI,Word Ptr Scr_Ofs[BX]
  Add   DI,X1
  Mov   AL,Colour
  Mov   AH,AL
  Mov   CX,X2
  Sub   CX,X1
  Shr   CX,1
  Jnc   @Start
  Stosb
@Start :
  Rep   Stosw
end;


Procedure Putpixel(X,Y  : Word;Colour : Byte;Where       : Word);Assembler;
Asm
    Mov AX,Where
    Mov ES,AX
    Mov BX,Y
    Shl BX,1
    Mov DI,Word Ptr Scr_Ofs[BX]
    Add DI,X
    Mov AL,Colour
    Mov ES:[DI],AL
End;
Procedure WaitRetrace;Assembler;
Asm
    Mov  DX,3DAh
@One:
    In   AL,DX
    Test AL,08h
    Jnz  @One
@Two:
    In   AL,DX
    Test AL,08h
    Jz   @Two
end;


Var Counter      : Word;

Begin
    For Counter := 0 to 199 Do
        Scr_Ofs[Counter] := Counter * 320;
End.
nd.
