#ifndef _TRANS_H_
#define _TRANS_H_

/** 3DGPL *************************************************\
 *  ()                                                    *
 *  Header for basic 3-d math.                            *
 *                                                        *
 *  trans-fl.c               3-D transformations, float;  *
 *  trans-fx.c               same using fixed point math; *
 *                                                        *
 *  (6/1995) By Sergei Savhenko. (savs@cs.mcgill.ca).     *
 *  Copyright (c) 1995 Sergei Savchenko.                  *
 *  THIS SOURCE CODE CAN'T BE USED FOR COMERCIAL PURPOSES *
 *  WITHOUT AUTHORISATION                                 *
\**********************************************************/

#define T_LOG_FOCUS 8                       /* log perspective foreshortening */

void T_init_math(void);

void T_translation(int *from,int *to,int length,int addx,int addy,int addz);
void T_scaling(int *from,int *to,int length,int mulx,int muly,int mulz);

void T_set_world_rotation(int alp,int bet,int gam);
void T_world_rotation(int *from,int *to,int length);
void T_set_self_rotation(int alp,int bet,int gam);
void T_self_rotation(int *from,int *to,int length);

void T_perspective(int *from,int *to,int dimension,int length);

/**********************************************************/

#endif
